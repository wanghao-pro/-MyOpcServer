=========================================================================
                       (c) ICONICS,Inc. 1986-2005
                          Simulator OPC Server
                               VERSION 3.12
                               March, 2005
=========================================================================




============================================
New features and issues in version  3.1
============================================

The OPC ToolWorX 3.1 (and then also the Simulator OPC Server 3.1)
is considered to be a major release.
There is a lot of changes in the 3.1 release. These changes
can be categorized into some categories:

- New code, i.e. new features provided by OPC ToolWorX 3.1
  (see the main tasks listed below).
- New implementation of internal routines and algorithms
  (see the main tasks listed below).
- Bug fixes.


New features in version 3.1: 
--------------------------------------------
- OPC DA3 interfaces added
- OPC AE 1.10 interfaces added
- OPC ComplexData support/documentation added
- TraceWorX support added (logging data into XML file)
- Address Space Online configuration
- Simple Alarms and Events supported
- Tracking Alarms and Events supported
- New Event Categories supported (OperatorProcessChange, SystemConfiguration, AdvancedControl, SystemMessage, BatchStatus, DeviceFailure)
- Recursive address space possible
- OPC-XML-DA wrapper installs with Simulator OPC Server / OPC ToolWorX (also as a redistributable)
- Lightweighted MemoryAS classes (COPCMemoryLightLeaf, COPCMemoryLightDataItem)
- ClassBranch concept to reduce/optimize memory consumption of server's address space stored in its memory
- Toolkit's/Server's internal counters and statistical info now accessible via COM interfaces
- OPC Admin utility installed as part of OPC ToolWorX 3.1 installation


New internal features in version 3.1: 
--------------------------------------------
- new internal update method on COPCSubscription class to improve responsivness (and OPC throughput) of OPC servers.
- new internal scanning algorithm to improve "device scanning" throughput of OPC servers.
- new internal concept of grouping Tag objects together to make the "burst read" as effective as possible (COPCChannel class involved in this concept)
- OPC Foundation files updated



============================================
Contacting ICONICS
============================================


For more information, you can contact ICONICS as follows:
Mail:	ICONICS, Inc.
	100 Foxboro Blvd.
	Foxboro, MA 02035 USA
Phone:	508-543-8600
Fax:	508-543-1503
WEB:	www.iconics.com

Email:	support@iconics.com. Use this address, in addition to the ftp site, 
for OPC questions and answers introduction.
